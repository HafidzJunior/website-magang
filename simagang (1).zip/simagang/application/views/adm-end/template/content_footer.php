<footer class="main-footer text-left small">
    <div class="float-right d-none d-sm-inline">
      <strong class="text-info">E-Magang | Internship</strong>
    </div>
    <strong>Copyright &copy; 2025.</strong> Repost By : <a href="https://www.youtube.com/@kaseps8304/videos">Kasep_Code</a>
</footer>