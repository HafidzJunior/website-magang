<div class="wh-api">
  <div class="wh-fixed">
    <a target="_blank" href="https://api.whatsapp.com/send?phone=+6289663112386&text=Saya lupa password">
      <button class="wh-ap-btn"></button>
    </a>
  </div>
</div>
<footer class="main-footer text-left small">
    <div class="container">
    	<div class="float-right d-none d-sm-inline">
	      <strong class="text-info">E-Magang | Internship</strong>
	    </div>
	    <strong>Copyright &copy; 2025 <a href="https://adminlte.io">AdminLTE.io</a>.</strong> All rights reserved.
    </div>
</footer>